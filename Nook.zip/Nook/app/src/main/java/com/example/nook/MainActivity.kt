@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
package com.example.nook

import android.app.role.RoleManager
import android.content.*
import android.content.pm.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.*
import java.time.LocalDateTime
import java.time.format.*
import kotlin.math.roundToInt

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("nook", 0)
    var iconDp by mutableStateOf(sp.getInt("icon", 56))
    var cols by mutableStateOf(sp.getInt("cols", 4))
    var theme by mutableStateOf(sp.getInt("theme", 0)) // 0 system, 1 light, 2 dark
    var pinned by mutableStateOf(sp.getString("pins", "")!!.split("|").filter { it.isNotEmpty() })
    fun save() = sp.edit().putInt("icon", iconDp).putInt("cols", cols).putInt("theme", theme)
        .putString("pins", pinned.joinToString("|")).apply()
}

data class App(val label: String, val pkg: String, val component: ComponentName, val user: UserHandle,
               val icon: ImageBitmap, val category: String, val system: Boolean) {
    val key get() = component.flattenToString() + user.toString()
    val letter get() = label.firstOrNull()?.uppercaseChar()?.takeIf { it.isLetter() } ?: '#'
}

object Repo {
    private val guess = listOf(
        "Games" to "game", "Media" to "camera|photo|gallery|music|video|player",
        "Communication" to "message|mms|dialer|contacts|phone|mail|chat",
        "Tools" to "settings|clock|calc|file|calendar")
    private fun category(ai: ApplicationInfo): String = when (ai.category) {
        ApplicationInfo.CATEGORY_GAME -> "Games"
        ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_IMAGE -> "Media"
        ApplicationInfo.CATEGORY_SOCIAL -> "Social"
        ApplicationInfo.CATEGORY_NEWS -> "News"
        ApplicationInfo.CATEGORY_MAPS -> "Travel"
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Work"
        else -> guess.firstOrNull { Regex(it.second).containsMatchIn(ai.packageName) }?.first ?: "Other"
    }
    fun load(ctx: Context): List<App> {
        val la = ctx.getSystemService(LauncherApps::class.java)
        return la.profiles.flatMap { la.getActivityList(null, it) }
            .filter { it.applicationInfo.packageName != ctx.packageName }
            .map { i ->
                val ai = i.applicationInfo
                val sys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                App(i.label.toString(), ai.packageName, i.componentName, i.user,
                    i.getBadgedIcon(0).toBitmap(128, 128).asImageBitmap(), category(ai), sys)
            }.sortedBy { it.label.lowercase() }
    }
}

fun openApp(ctx: Context, a: App) = try {
    ctx.getSystemService(LauncherApps::class.java).startMainActivity(a.component, a.user, null, null)
} catch (e: Exception) { Toast.makeText(ctx, "Can't open ${a.label}", Toast.LENGTH_SHORT).show() }

class MainActivity : ComponentActivity() {
    private val homeTick = mutableIntStateOf(0)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = Prefs(this)
        setContent { NookApp(prefs, homeTick.intValue) }
    }
    // Pressing Home while already open returns to the home screen.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) homeTick.intValue++
    }
}

@Composable fun NookApp(p: Prefs, tick: Int) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<App>()) }
    var screen by remember { mutableIntStateOf(0) } // 0 home, 1 drawer, 2 settings
    LaunchedEffect(tick) { screen = 0 }
    DisposableEffect(Unit) {
        val la = ctx.getSystemService(LauncherApps::class.java)
        val scope = CoroutineScope(Dispatchers.Main)
        val reload = { scope.launch { apps = withContext(Dispatchers.Default) { Repo.load(ctx) } }; Unit }
        val cb = object : LauncherApps.Callback() {
            override fun onPackageRemoved(n: String, u: UserHandle) { reload() }
            override fun onPackageAdded(n: String, u: UserHandle) { reload() }
            override fun onPackageChanged(n: String, u: UserHandle) { reload() }
            override fun onPackagesAvailable(n: Array<out String>, u: UserHandle, r: Boolean) { reload() }
            override fun onPackagesUnavailable(n: Array<out String>, u: UserHandle, r: Boolean) { reload() }
        }
        la.registerCallback(cb); reload()
        onDispose { la.unregisterCallback(cb); scope.cancel() }
    }
    val pin = { a: App ->
        p.pinned = if (a.key in p.pinned) p.pinned - a.key else p.pinned + a.key; p.save()
    }
    val dark = when (p.theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        BackHandler(screen != 0) { screen = 0 }
        when (screen) {
            0 -> Home(apps, p, { screen = it }, pin)
            1 -> Drawer(apps, p, { screen = it }, pin)
            else -> SettingsScreen(p) { screen = 0 }
        }
    }
}

@Composable fun Home(apps: List<App>, p: Prefs, open: (Int) -> Unit, pin: (App) -> Unit) {
    val now by produceState(LocalDateTime.now()) {
        while (true) { value = LocalDateTime.now(); delay(60_000 - System.currentTimeMillis() % 60_000) }
    }
    val pins = p.pinned.mapNotNull { k -> apps.find { it.key == k } }
    Column(Modifier.fillMaxSize().background(Color.Black.copy(.3f))
        .pointerInput(Unit) {
            var drag = 0f
            detectVerticalDragGestures(onDragStart = { drag = 0f }, onDragEnd = { if (drag < -100f) open(1) }) { _, dy -> drag += dy }
        }
        .pointerInput(Unit) { detectTapGestures(onLongPress = { open(2) }) }
        .statusBarsPadding().navigationBarsPadding().padding(20.dp)) {
        Text(now.format(DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT)), color = Color.White, fontSize = 64.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Light)
        Text(now.format(DateTimeFormatter.ofPattern("EEEE, MMMM d")), color = Color.White, fontSize = 18.sp)
        Spacer(Modifier.height(20.dp))
        Surface(Modifier.fillMaxWidth().clickable(onClickLabel = "Search apps") { open(1) },
            shape = MaterialTheme.shapes.extraLarge, color = Color.White.copy(.2f)) {
            Text("Search apps", color = Color.White, modifier = Modifier.padding(16.dp))
        }
        Spacer(Modifier.height(16.dp))
        if (pins.isEmpty()) Text("Long-press an app in the drawer to add it here.", color = Color.White.copy(.8f))
        LazyVerticalGrid(GridCells.Fixed(p.cols), Modifier.weight(1f)) {
            items(pins, key = { it.key }) { AppCell(it, p, true, Color.White, pin) }
        }
        TextButton({ open(1) }, Modifier.align(Alignment.CenterHorizontally)) { Text("All apps  ⌃", color = Color.White) }
    }
}

@Composable fun AppCell(a: App, p: Prefs, pinned: Boolean, color: Color, pin: (App) -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    Box {
        Column(Modifier.fillMaxWidth().combinedClickable(onClick = { openApp(ctx, a) }, onLongClick = { menu = true }).padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Image(a.icon, a.label, Modifier.size(p.iconDp.dp))
            Text(a.label, color = color, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem({ Text("App info") }, {
                menu = false
                try { ctx.getSystemService(LauncherApps::class.java).startAppDetailsActivity(a.component, a.user, null, null) } catch (_: Exception) {}
            })
            if (!a.system) DropdownMenuItem({ Text("Uninstall") }, {
                menu = false
                ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
            })
            DropdownMenuItem({ Text(if (pinned) "Remove from home" else "Add to home") }, { menu = false; pin(a) })
        }
    }
}

@Composable fun Drawer(apps: List<App>, p: Prefs, open: (Int) -> Unit, pin: (App) -> Unit) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("All") }
    val cats = remember(apps) { listOf("All") + apps.map { it.category }.distinct().sorted() }
    val list = apps.filter { (cat == "All" || it.category == cat) && it.label.contains(q, true) }
    val st = rememberLazyGridState(); val sc = rememberCoroutineScope()
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface.copy(.95f)) {
        Column(Modifier.statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(q, { q = it }, Modifier.weight(1f), placeholder = { Text("Search apps") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { list.firstOrNull()?.let { openApp(ctx, it) } }))
                TextButton({ open(2) }) { Text("Settings") }
            }
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(cats) { c -> FilterChip(cat == c, { cat = c }, { Text(c) }) }
            }
            Row(Modifier.weight(1f)) {
                LazyVerticalGrid(GridCells.Fixed(p.cols), Modifier.weight(1f), st, PaddingValues(8.dp)) {
                    items(list, key = { it.key }) { AppCell(it, p, it.key in p.pinned, MaterialTheme.colorScheme.onSurface, pin) }
                }
                Column(Modifier.fillMaxHeight().padding(end = 2.dp), Arrangement.SpaceEvenly) {
                    list.map { it.letter }.distinct().forEach { l ->
                        Text("$l", Modifier.clickable { sc.launch { st.scrollToItem(list.indexOfFirst { it.letter == l }) } }.padding(horizontal = 8.dp),
                            fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable fun SettingsScreen(p: Prefs, back: () -> Unit) {
    val ctx = LocalContext.current
    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Settings", style = MaterialTheme.typography.headlineMedium)
            Text("Icon size: ${p.iconDp}dp")
            Slider(p.iconDp.toFloat(), { p.iconDp = it.toInt() }, valueRange = 40f..72f, onValueChangeFinished = { p.save() })
            Text("Grid columns: ${p.cols}")
            Slider(p.cols.toFloat(), { p.cols = it.roundToInt() }, valueRange = 3f..6f, steps = 2, onValueChangeFinished = { p.save() })
            Text("Theme")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("System", "Light", "Dark").forEachIndexed { i, n -> FilterChip(p.theme == i, { p.theme = i; p.save() }, { Text(n) }) }
            }
            Button({ ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper")) }) { Text("Change wallpaper") }
            Button({
                val rm = if (Build.VERSION.SDK_INT >= 29) ctx.getSystemService(RoleManager::class.java) else null
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME))
                    ctx.startActivity(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                else ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            }) { Text("Set as default launcher") }
            OutlinedButton(back) { Text("Done") }
        }
    }
}
