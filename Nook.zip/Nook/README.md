# Nook Launcher (Kotlin + Jetpack Compose, minSdk 26)
## Build
1. Open this folder in Android Studio (Koala+), let it sync (generates the Gradle wrapper), then Run, or:
2. CLI: `gradle wrapper && ./gradlew assembleDebug` -> app/build/outputs/apk/debug/app-debug.apk
3. Install: `adb install -r app/build/outputs/apk/debug/app-debug.apk`
## Permissions
- REQUEST_DELETE_PACKAGES: only so "Uninstall" can open the system uninstall prompt.
- No QUERY_ALL_PACKAGES, storage or location. Apps are read via the LauncherApps API.
- Wallpaper uses the system picker (no wallpaper permission).
## Set as default launcher
- [ ] Install, open Nook once -> Settings -> "Set as default launcher" -> choose Nook.
- [ ] (Or Android Settings > Apps > Default apps > Home app > Nook.)
- [ ] Press Home: Nook shows. Press Home again inside the drawer: returns to home.
- [ ] Back closes drawer/settings; Back on home does nothing (launcher behaviour).
- [ ] Verify: icons match real apps, tap launches, long-press -> info/uninstall/pin, new installs appear live.
## Restrictions
- System apps can't be uninstalled (menu item hidden). Work-profile uninstall isn't supported by ACTION_DELETE.
- Setting the default Home app always needs user confirmation. Wallpaper is chosen via the system picker.
- Not implemented yet: widgets, app-icon packs, gestures beyond swipe-up/long-press, drag-to-reorder, notification badges.
